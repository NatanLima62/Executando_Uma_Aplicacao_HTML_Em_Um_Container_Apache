const formulario = document.forms[0];
const dados= {};

function handleKeyUp(event) {
  const target = event.target;
  if (!target.checkValidity()) {
    target.classList.add("invalido");
    formulario.nome.setCustomValidity("Campo invalido");
    formulario.email.setCustomValidity("Email é valido");
    target.nextElementSibling.innerText = target.validationMessage;
  }
}

function handleChange(event) {
  console.log(event.target.name);
  dados[event.target.name] = event.target.value;
}

formulario.addEventListener("change", handleChange);
